package infection.need

import org.amcgala.vr.{ Position, BotAgent, Bot }
import org.amcgala.vr.need.{ Need, SatisfactionBehavior }
import example.LocationService
import org.amcgala.vr.building.BuildingType.Restaurant
import org.amcgala.vr.need.Needs.Hunger
import akka.actor.ActorRef
import example.LocationService.Coordinate
import scala.util.Random

class InfectorBehavior()(implicit val bot: Bot) extends SatisfactionBehavior {

  import scala.concurrent.ExecutionContext.Implicits.global

  type Return = LocationService.Cell

  private val target = Coordinate(Random.nextInt(200), Random.nextInt(200))

  def start() = {
    for {
      map ← bot.executeTask(LocationService.findNextBotFrom(bot))
      ho <- map.headOption
      pos = new LocationService.Coordinate(map.head._2.x, map.head._2.y)
      mcd ← bot.executeTask(LocationService.walkTo(pos)(bot))
    } yield {
      done = true
      //need.decrease(49)
      mcd
    }

  }

  val need: Need = Hunger()

}
