package org.amcgala.vr.capability

/**
  * Marker trait for all things a [[org.amcgala.vr.BotAgent]] is capable of doing.
  */
trait BotCapability
